package com.xuanlocle;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class AvgTempPerYear {

    public static class TempMapper
            extends Mapper<Object, Text, IntWritable, DoubleWritable> {

        private IntWritable yearInt = new IntWritable();
        private DoubleWritable temperature = new DoubleWritable();

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            String tempStr;
            if (line.charAt(87) == '+') {
                tempStr = line.substring(88, 92);
            } else {
                tempStr = line.substring(87, 92);
            }
            int airTemp = Integer.parseInt(tempStr);


            double temp = airTemp / 10.0;
            int year = Integer.parseInt(line.substring(15, 19));
            yearInt.set(year);
            temperature.set(temp);
            context.write(yearInt, temperature);
        }
    }

    public static class AvgReducer
            extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {

        private DoubleWritable result = new DoubleWritable();

        public void reduce(IntWritable yr, Iterable<DoubleWritable> values,
                           Context context)
                throws IOException, InterruptedException {
            double sum = 0;
            int count = 0;
            for (DoubleWritable temperature : values) {
                sum += temperature.get();
                count += 1;
            }
            result.set(sum / count);
            context.write(yr, result);

        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job;
        boolean isLocal = args.length > 2 && "local".equals(args[2]);
        if (isLocal) {
            System.out.println("Running in local mode...");
            conf.set("fs.defaultFS", "file:///"); // Use local filesystem instead of HDFS
            conf.set("mapreduce.framework.name", "local"); // Use the local job runner
            job = Job.getInstance(conf, "local Average Temperature Per Year");
        } else {
            job = Job.getInstance(conf, "Average Temperature Per Year");
        }
        job.setJarByClass(AvgTempPerYear.class);

        job.setMapperClass(TempMapper.class);
        job.setReducerClass(AvgReducer.class);

        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(DoubleWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}