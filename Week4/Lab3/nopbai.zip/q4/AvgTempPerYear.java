package com.xuanlocle;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.DataInput;
import java.io.DataOutput;

public class AvgTempPerYear {
    public static class YearWritable implements WritableComparable<YearWritable> {

        private int year;

        public YearWritable() {
        }

        public YearWritable(int y) {
            year = y;
        }

        public void set(int y) {
            year = y;
        }

        public int get() {
            return year;
        }

        @Override
        public void write(DataOutput out) throws IOException {
            out.writeInt(year);
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            year = in.readInt();
        }

        @Override
        public int compareTo(YearWritable other) {
            return Integer.compare(other.year, this.year);
        }

        @Override
        public String toString() {
            return Integer.toString(year);
        }
    }

    public static class SumCountWritable implements Writable {

        private double sum;
        private int count;

        public SumCountWritable() {
        }

        public SumCountWritable(double s, int c) {
            sum = s;
            count = c;
        }

        public void write(DataOutput out) throws IOException {
            out.writeDouble(sum);
            out.writeInt(count);
        }

        public void readFields(DataInput in) throws IOException {
            sum = in.readDouble();
            count = in.readInt();
        }

        public double getSum() {
            return sum;
        }

        public int getCount() {
            return count;
        }

        public void set(double s, int c) {
            sum = s;
            count = c;
        }
    }

    public static class TempMapper extends Mapper<Object, Text, YearWritable, SumCountWritable> {

        private Map<Integer, SumCountWritable> yearMap;

        public void setup(Context context) {
            yearMap = new HashMap<>();
        }

        public void map(Object key, Text value, Context context) {

            String line = value.toString();
            String tempStr;
            if (line.charAt(87) == '+')
                tempStr = line.substring(88, 92);
            else
                tempStr = line.substring(87, 92);

            int airTemp = Integer.parseInt(tempStr);


            double temp = airTemp / 10.0;
            int year = Integer.parseInt(line.substring(15, 19));

            SumCountWritable current = yearMap.get(year);

            if (current == null) {
                yearMap.put(year, new SumCountWritable(temp, 1));
            } else {
                current.set(current.getSum() + temp, current.getCount() + 1);
            }
        }

        public void cleanup(Context context)
                throws IOException, InterruptedException {

            for (Map.Entry<Integer, SumCountWritable> entry : yearMap.entrySet()) {
                context.write(new YearWritable(entry.getKey()), entry.getValue());
            }
        }
    }

    public static class AvgReducer
            extends Reducer<YearWritable, SumCountWritable, YearWritable, DoubleWritable> {

        private DoubleWritable result = new DoubleWritable();

        public void reduce(YearWritable key, Iterable<SumCountWritable> values,
                           Context context)
                throws IOException, InterruptedException {
            double sum = 0;
            int count = 0;

            for (SumCountWritable val : values) {
                sum += val.getSum();
                count += val.getCount();
            }
            result.set(sum / count);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job;
        boolean isLocal = args.length > 2 && "local".equals(args[2]);
        if (isLocal) {
            System.out.println("Running in local mode...");
            conf.set("fs.defaultFS", "file:///"); // Use local filesystem instead of HDFS
            conf.set("mapreduce.framework.name", "local"); // Use the local job runner
            job = Job.getInstance(conf, "local Average Temperature Per Year");
        } else {
            job = Job.getInstance(conf, "Average Temperature Per Year");
        }
        job.setJarByClass(AvgTempPerYear.class);
        job.setMapperClass(TempMapper.class);
        job.setReducerClass(AvgReducer.class);

        job.setMapOutputKeyClass(YearWritable.class);
        job.setMapOutputValueClass(SumCountWritable.class);

        job.setOutputKeyClass(YearWritable.class);
        job.setOutputValueClass(DoubleWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}