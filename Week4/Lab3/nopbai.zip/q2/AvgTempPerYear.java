package com.xuanlocle;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class AvgTempPerYear {
    public static class SumCountWritable implements Writable {

        private double sum;
        private int count;

        public SumCountWritable() {
        }

        public SumCountWritable(double sum, int count) {
            this.sum = sum;
            this.count = count;
        }

        public void write(DataOutput out) throws IOException {
            out.writeDouble(sum);
            out.writeInt(count);
        }

        public void readFields(DataInput in) throws IOException {
            sum = in.readDouble();
            count = in.readInt();
        }

        public double getSum() {
            return sum;
        }

        public int getCount() {
            return count;
        }

        public void set(double sum, int count) {
            this.sum = sum;
            this.count = count;
        }
    }

    public static class TempMapper
            extends Mapper<Object, Text, IntWritable, SumCountWritable> {

        private IntWritable yearInt = new IntWritable();
        private SumCountWritable tempCount = new SumCountWritable();

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            String tempStr;
            if (line.charAt(87) == '+') {
                tempStr = line.substring(88, 92);
            } else {
                tempStr = line.substring(87, 92);
            }
            int airTemp = Integer.parseInt(tempStr);


            double temp = airTemp / 10.0;
            int year = Integer.parseInt(line.substring(15, 19));
            yearInt.set(year);
            tempCount.set(temp, 1);

            context.write(yearInt, tempCount);
        }
    }

    public static class AvgCombiner
            extends Reducer<IntWritable, SumCountWritable, IntWritable, SumCountWritable> {

        private SumCountWritable result = new SumCountWritable();

        public void reduce(IntWritable key, Iterable<SumCountWritable> values,
                           Context context) throws IOException, InterruptedException {

            double sum = 0;
            int count = 0;

            for (SumCountWritable val : values) {
                sum += val.getSum();
                count += val.getCount();
            }

            result.set(sum, count);
            context.write(key, result);
        }
    }

    public static class AvgReducer
            extends Reducer<IntWritable, SumCountWritable, IntWritable, DoubleWritable> {

        private DoubleWritable result = new DoubleWritable();

        public void reduce(IntWritable key, Iterable<SumCountWritable> values,
                           Context context)
                throws IOException, InterruptedException {
            double sum = 0;
            int count = 0;

            for (SumCountWritable val : values) {
                sum += val.getSum();
                count += val.getCount();
            }
            result.set(sum / count);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job;
        boolean isLocal = args.length > 2 && "local".equals(args[2]);
        if (isLocal) {
            System.out.println("Running in local mode...");
            conf.set("fs.defaultFS", "file:///"); // Use local filesystem instead of HDFS
            conf.set("mapreduce.framework.name", "local"); // Use the local job runner
            job = Job.getInstance(conf, "local Average Temperature Per Year");
        } else {
            job = Job.getInstance(conf, "Average Temperature Per Year");
        }
        job.setJarByClass(AvgTempPerYear.class);
        job.setMapperClass(TempMapper.class);
        job.setCombinerClass(AvgCombiner.class);
        job.setReducerClass(AvgReducer.class);

        job.setMapOutputKeyClass(IntWritable.class);
        job.setMapOutputValueClass(SumCountWritable.class);

        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(DoubleWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}