Hadoop MapReduce – Average Temperature Per Year with combiner

Step to do:

- Build the jar file: mvn clean package
- Copy the jar file to the Hadoop folder: cp target/AvgTemp-1.0.jar /opt/my_code/
- Create input folder in HDFS: hdfs dfs -mkdir -p input
- Upload the input file to HDFS: hdfs dfs -put NCDC-Weather.txt input
- Run the Hadoop MapReduce job: hadoop jar my_code/AvgTemp-1.0.jar com.xuanlocle.AvgTempPerYear input output
- If output folder already exists, remove it: hdfs dfs -rm -r output
- Check the result: hdfs dfs -cat output/part-r-00000