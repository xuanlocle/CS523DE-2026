import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import java.io.IOException;
import java.util.StringTokenizer;

public class WordCount {

    /**
     * Mapper class for the WordCount job.
     * <p>
     * The input is a key-value pair where the key is the byte offset (LongWritable)
     * and the value is the line of text (Text).
     * The output is a key-value pair where the key is a word (Text) and the value is 1 (IntWritable).
     */
    public static class WordCountMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
        private final static IntWritable one = new IntWritable(1);
        private Text word = new Text();

        /**
         * Maps each line of text to a set of words.
         *
         * @param key     The byte offset of the line in the file (ignored).
         * @param value   The content of the line (record).
         * @param context The context to write output to.
         */
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString().toLowerCase();   // convert to lowercase
            StringTokenizer tokenizer = new StringTokenizer(line);

            while (tokenizer.hasMoreTokens()) {
                String token = tokenizer.nextToken();
                token = token.replaceAll("[^a-z]", "");     // remove punctuation

                if (!token.isEmpty()) {
                    word.set(token);
                    context.write(word, one);
                }
            }
        }
    }

    /**
     * Reducer class for the WordCount job.
     * <p>
     * Receives a word and a list of counts (all 1s) from the Mapper.
     * Sums up the counts to produce the total frequency for that word.
     */
    public static class WordCountReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
        private IntWritable result = new IntWritable();

        /**
         * Reduces the list of values for a given key to a single sum.
         *
         * @param key     The word.
         * @param values  An iterable of counts for this word.
         * @param context The context to write the final result to.
         */
        public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int sum = 0;
            // Sum up all the counts for the current word
            for (IntWritable val : values) {
                sum += val.get();
            }

            // Only output words that appear at least 25 times
            if (sum >= 25) {
                result.set(sum);
                // Write the word and its total count to output
                context.write(key, result);
            }
        }
    }

    /**
     * Main entry point for the Hadoop MapReduce application.
     * Configures and submits the MapReduce job.
     */
    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.err.println("Usage: WordCount <input path> <output path>");
            System.exit(-1);
        }
        // Check for a special "local" argument to run without a full HDFS/YARN cluster
        boolean isLocal = args.length > 2 && "local".equals(args[2]);

        Configuration conf = new Configuration();
        Job job;

        // Configure the job for local execution if requested
        if (isLocal) {
            System.out.println("Running in local mode...");
            conf.set("fs.defaultFS", "file:///"); // Use local filesystem instead of HDFS
            conf.set("mapreduce.framework.name", "local"); // Use the local job runner
            job = Job.getInstance(conf, "local word count");
        } else {
            job = Job.getInstance(conf, "word count");
        }

        job.setJarByClass(WordCount.class);

        // Set Mapper and Reducer classes
        job.setMapperClass(WordCountMapper.class);
        job.setReducerClass(WordCountReducer.class);

        // Define the output key and value types
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        // Define input and output formats (TextInputFormat parses lines, TextOutputFormat writes "key \t val")
        job.setInputFormatClass(TextInputFormat.class); // This input format is default, so this line could be omitted
        job.setOutputFormatClass(TextOutputFormat.class); // This output format is default, so this line could be omitted

        // Set input and output paths from command line arguments
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        // Submit the job and wait for completion
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
