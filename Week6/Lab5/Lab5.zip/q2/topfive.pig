users = LOAD './users.csv' USING PigStorage(',') AS (name:chararray, age:int);
filtered_ages = FILTER users BY age >= 18 AND age <= 25;

pages = LOAD './pages.csv' USING PigStorage(',') AS (username:chararray, website:chararray);

joined_data = JOIN filtered_ages BY name, pages BY username;
sites_result = FOREACH joined_data GENERATE website;

grouped_sites = GROUP sites_result BY website;
recordcount = FOREACH grouped_sites GENERATE group AS site, COUNT(sites_result) AS cnt;

ordered = ORDER recordcount BY cnt DESC;
topFive = LIMIT ordered 5;

STORE topFive INTO 'output' USING PigStorage(',');