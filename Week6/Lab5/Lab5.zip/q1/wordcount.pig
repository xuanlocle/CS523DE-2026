records = LOAD 'InputForWC.txt' USING TextLoader() AS (wordline:chararray);

cleaned = FOREACH records GENERATE REPLACE(wordline, '\\t', ' ') AS line;

tBag = FOREACH cleaned GENERATE TOKENIZE(line) AS wordsBag;

flatData = FOREACH tBag GENERATE FLATTEN(wordsBag) AS token:chararray;

grecords = GROUP flatData BY token;

recordcount = FOREACH grecords GENERATE group AS word, COUNT(flatData) AS count;

STORE recordcount INTO 'output';